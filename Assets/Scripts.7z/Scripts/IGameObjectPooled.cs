﻿interface IGameObjectPooled
{
    ObjectPool Pool { get; set; }
}
