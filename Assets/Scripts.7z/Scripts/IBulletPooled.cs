﻿interface IBulletPooled
{
    BulletPool Pool { get; set; }
}